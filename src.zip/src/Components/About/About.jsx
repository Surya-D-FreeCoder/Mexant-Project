import React from 'react'
import Abouthome from '../Homepage/Abouthome'


export default function About() {
  return (
    <div>
        <Abouthome/>
    </div>
  )
}
