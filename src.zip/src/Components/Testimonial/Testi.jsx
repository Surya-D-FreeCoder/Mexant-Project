import React from 'react'
import Test from '../Homepage/Test'

export default function Testi() {
  return (
    <div>
        <Test/>
    </div>
  )
}
