import React from 'react'
import Contact from '../Homepage/Contact'

export default function Contacts() {
  return (
    <div>
        <Contact/>
    </div>
  )
}
