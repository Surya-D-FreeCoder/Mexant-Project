import React from 'react'
import Listcards from '../Homepage/Listcards'

export default function Service() {
  return (
    <div className='service-page'>
        <Listcards/>
    </div>
  )
}
